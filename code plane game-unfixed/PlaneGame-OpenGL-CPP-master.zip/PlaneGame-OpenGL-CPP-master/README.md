# PlaneGame-OpenGL
Window 1 :
![Screenshot](https://github.com/rksazid/PlaneGame-OpenGL-CPP/blob/master/2019-01-18_185333.jpg)

Window 2:
![Screenshot](https://github.com/rksazid/PlaneGame-OpenGL-CPP/blob/master/2019-01-18_185529.jpg)
